package sample;

import java.util.HashMap;
import java.util.Map;

public class SPGModel {


}

