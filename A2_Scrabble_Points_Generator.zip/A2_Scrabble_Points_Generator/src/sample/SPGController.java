package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.HashMap;
import java.util.Map;

public class SPGController {

    static HashMap<Character, Integer> Alphabet_Score = new HashMap<Character, Integer>();



    @FXML
    TextField score;

    public static int calculate(String word) {
        int result = 0;
        word = word.toUpperCase();
        for(int i = 0; i <word.length();i++) {
            //look up the current char in the alphabet and add it's value to sum
            result += Alphabet_Score.get(word.charAt(i));
        }
        return result;

    }

    @FXML
    private void initialize() {

        System.out.println("Success!");
        score.setText("");

        Alphabet_Score.put('A', 1);
        Alphabet_Score.put('B', 3);
        Alphabet_Score.put('C', 3);
        Alphabet_Score.put('D', 2);
        Alphabet_Score.put('E', 1);
        Alphabet_Score.put('F', 4);
        Alphabet_Score.put('G', 2);
        Alphabet_Score.put('H', 4);
        Alphabet_Score.put('I', 1);
        Alphabet_Score.put('J', 8);
        Alphabet_Score.put('K', 5);
        Alphabet_Score.put('L', 1);
        Alphabet_Score.put('M', 3);
        Alphabet_Score.put('N', 1);
        Alphabet_Score.put('O', 1);
        Alphabet_Score.put('P', 3);
        Alphabet_Score.put('Q', 10);
        Alphabet_Score.put('R', 1);
        Alphabet_Score.put('S', 1);
        Alphabet_Score.put('T', 1);
        Alphabet_Score.put('U', 1);
        Alphabet_Score.put('V', 4);
        Alphabet_Score.put('W', 4);
        Alphabet_Score.put('X', 8);
        Alphabet_Score.put('Y', 4);
        Alphabet_Score.put('Z', 10);

    }

}
